/*
Ahsanullah University of Science and Technology
Department of Computer Science and Engineering
Lab Final Examination
Course: CSE 4130 (Formal Languages and Compilers Lab)
Year/Sems: 4/1                           Session: FALL 2020
ID: 170204048                    Set:
*/
#include<stdio.h>
char line[1000][1000];
int main()
{
    FILE *p1,*p2,*p3,*p4;
    char c,d,e;
    int i,j;


    return 0;
}

